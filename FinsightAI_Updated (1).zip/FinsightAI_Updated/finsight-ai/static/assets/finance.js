/* FinSight AI — Income history, automatic savings and AI budget prediction */
(function () {
  const byId = (id) => document.getElementById(id);
  const today = new Date();
  const currentMonth = today.toISOString().slice(0, 7);
  const currentDate = today.toISOString().slice(0, 10);
  let currentBudgetDraft = null;

  function esc(value) { return window.escapeHtml ? escapeHtml(value) : String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function fmt(value) { return window.money ? money(value) : '₹' + Number(value || 0).toLocaleString('en-IN'); }
  function selectedMonth(id) { return byId(id)?.value || currentMonth; }

  async function loadIncomeModule() {
    const monthInput = byId('financeMonth');
    if (monthInput && !monthInput.value) monthInput.value = currentMonth;
    const month = selectedMonth('financeMonth');
    const [income, history, savings, prefs] = await Promise.all([
      api(`/finance/income?month=${encodeURIComponent(month)}`),
      api(`/finance/history?months=2&end_month=${encodeURIComponent(month)}`),
      api('/finance/savings-settings'),
      api('/finance/notification-preferences')
    ]);
    byId('incomeSalary').textContent = fmt(income.salary.amount);
    byId('incomeAdditional').textContent = fmt(income.additional_income);
    byId('incomeTotal').textContent = fmt(income.total_income);
    const chosen = history.history[history.history.length - 1];
    byId('incomeSavings').textContent = fmt(chosen?.automatic_savings || 0);
    byId('incomeSpendable').textContent = fmt(chosen?.spendable_budget || 0);
    byId('incomeExpenses').textContent = fmt(chosen?.total_expenses || 0);

    if (byId('salaryAmount')) byId('salaryAmount').value = income.salary.amount || '';
    if (byId('salaryEffectiveMonth') && !byId('salaryEffectiveMonth').value) byId('salaryEffectiveMonth').value = month;
    if (byId('incomeDate') && !byId('incomeDate').value) byId('incomeDate').value = currentDate;
    renderIncomeTransactions(income.income_transactions || []);
    renderFinanceHistory(history.history || []);

    byId('savingsEnabled').checked = !!savings.enabled;
    byId('savingsMethod').value = savings.method;
    byId('savingsValue').value = savings.value;
    byId('bonusSavingsPercentage').value = savings.bonus_savings_percentage;
    byId('dailyNotifEnabled').checked = !!prefs.daily_enabled;
    byId('weeklyNotifEnabled').checked = !!prefs.weekly_enabled;
    byId('monthlyNotifEnabled').checked = !!prefs.monthly_enabled;
    byId('browserNotifEnabled').checked = !!prefs.browser_enabled;
    byId('reminderTime').value = prefs.reminder_time || '09:00';
  }

  function renderIncomeTransactions(items) {
    const el = byId('incomeTransactionList');
    if (!items.length) {
      el.innerHTML = '<p class="muted">No bonus or additional income recorded for this month.</p>';
      return;
    }
    el.innerHTML = items.map(item => `
      <div class="finance-list-row">
        <div><b>${esc(item.description)}</b><small>${esc(item.income_type)} · ${esc(item.transaction_date)}</small></div>
        <strong class="finance-positive">+${fmt(item.amount)}</strong>
        <button class="text-btn" onclick="deleteIncomeRecord(${Number(item.id)})">Delete</button>
      </div>`).join('');
  }

  function renderFinanceHistory(items) {
    const body = byId('financeHistoryTable');
    if (!items.length) { body.innerHTML = '<tr><td colspan="7">No history available.</td></tr>'; return; }
    body.innerHTML = items.map(item => `
      <tr><td><b>${esc(item.month)}</b></td><td>${fmt(item.salary_income)}</td>
      <td>${fmt(item.additional_income)}</td><td><b>${fmt(item.total_income)}</b></td>
      <td>${fmt(item.total_expenses)}</td><td class="finance-positive">${fmt(item.automatic_savings)}</td>
      <td>${fmt(item.unallocated_after_expenses)}</td></tr>`).join('');
  }

  async function deleteIncomeRecord(id) {
    if (!confirm('Delete this additional income record?')) return;
    try {
      await api(`/finance/income/${id}`, { method: 'DELETE' });
      showToast('Income record deleted', 'success');
      await loadIncomeModule();
      await loadDashboard();
    } catch (e) { showToast(e.message, 'error'); }
  }
  window.deleteIncomeRecord = deleteIncomeRecord;

  async function loadBudgetPredictionModule() {
    const monthInput = byId('predictionMonth');
    if (monthInput && !monthInput.value) monthInput.value = currentMonth;
    const month = selectedMonth('predictionMonth');
    const data = await api(`/finance/budget-prediction?month=${encodeURIComponent(month)}`);
    byId('predSalary').textContent = fmt(data.salary_income);
    byId('predAdditional').textContent = fmt(data.additional_income);
    byId('predExpenses').textContent = fmt(data.predicted_expenses);
    byId('predSavings').textContent = fmt(data.automatic_savings);
    byId('predSpendable').textContent = fmt(data.spendable_budget);
    byId('predConfidence').textContent = data.forecast_confidence ? `${Math.round(data.forecast_confidence * 100)}%` : 'Limited data';
    byId('predRemaining').textContent = fmt(data.predicted_savings_after_expenses);
    byId('predActualExpenses').textContent = fmt(data.actual_expenses_to_date);
    byId('predTrend').textContent = data.trend?.trend || 'Not enough history';
    byId('predictionExplanation').textContent = `${data.note} Recommended category budgets total ${fmt(data.recommended_budget_total)}; ${fmt(data.unallocated_spendable_budget)} remains unallocated as a cushion.`;
    renderCategoryPredictions(data);
    await loadSavingTips(false);
  }

  function renderCategoryPredictions(data) {
    const el = byId('predCategoryList');
    const entries = Object.entries(data.category_allocations || {});
    if (!entries.length) { el.innerHTML = '<p class="muted">No category forecasts available yet. Add historical expenses to train the forecast.</p>'; return; }
    const maximum = Math.max(...entries.map(([, amount]) => Number(amount)), 1);
    el.innerHTML = entries.sort((a,b) => b[1]-a[1]).map(([category, amount]) => {
      const forecast = Number(data.category_predictions?.[category] || 0);
      const pct = Math.max(0, Math.min(100, Number(amount) / maximum * 100));
      return `<div class="finance-category-row"><div class="finance-category-head"><b>${esc(category)}</b><strong>${fmt(amount)}</strong></div>
        <div class="finance-progress"><span style="width:${pct}%"></span></div>
        <small>Historical ML forecast: ${fmt(forecast)} · Recommended limit includes a modest buffer</small></div>`;
    }).join('');
  }

  async function loadSavingTips(showMessage = true) {
    const month = selectedMonth('predictionMonth');
    try {
      const data = await api(`/finance/saving-tips?month=${encodeURIComponent(month)}`);
      const el = byId('savingTipsList');
      el.innerHTML = (data.tips || []).map(tip => `
        <div class="finance-tip-card"><span class="finance-tip-priority ${esc(tip.priority || 'medium')}">${esc(tip.priority || 'tip')}</span>
          <div><b>${esc(tip.title)}</b><p>${esc(tip.message)}</p><small>${esc(tip.category || 'General')}</small></div></div>`).join('') || '<p class="muted">No tips available.</p>';
      byId('savingTipsSource').textContent = `Insights generated by: ${data.generated_by}`;
      if (showMessage) showToast('Saving tips refreshed', 'success');
    } catch (e) { if (showMessage) showToast(e.message, 'error'); }
  }


  async function generateBudgetPlan() {
    const month = byId('budgetPlanMonth')?.value || currentMonth;
    const button = byId('generateBudgetPlanBtn');
    if (button) { button.disabled = true; button.textContent = 'Generating…'; }
    try {
      const result = await api('/budgets/ai-plan', { method: 'POST', body: { month } });
      currentBudgetDraft = result.plan;
      renderBudgetPlan(result.plan);
      showToast('Budget plan generated. Review it before applying.', 'success');
    } catch (e) { showToast(e.message, 'error'); }
    finally { if (button) { button.disabled = false; button.textContent = '✦ Generate My Budget Plan'; } }
  }

  function renderBudgetPlan(plan) {
    const panel = byId('budgetPlanPreview');
    panel.style.display = 'block';
    byId('budgetPlanMeta').textContent = `For ${plan.month}. Based on ${plan.history_months.join(', ')}. This is a draft and is not saved until you click Apply Budget.`;
    byId('budgetPlanSummary').innerHTML = [
      ['Salary', plan.salary_income], ['Additional income', plan.additional_income],
      ['Total income', plan.total_income], ['Automatic savings', plan.automatic_savings],
      ['Spendable budget', plan.spendable_budget], ['Predicted expenses', plan.predicted_expenses]
    ].map(([label, value]) => `<div class="finance-summary-card"><small>${esc(label)}</small><b>${fmt(value)}</b></div>`).join('');
    byId('budgetPlanInsights').innerHTML = `<div class="finance-tip-card"><span class="finance-tip-priority medium">Analysis</span><div><b>How this plan was created</b><p>${esc(plan.explanation)} Confidence estimate: ${Math.round(Number(plan.forecast_confidence || 0) * 100)}%.</p></div></div>` +
      (plan.insights || []).map(item => `<div class="finance-tip-card"><span class="finance-tip-priority ${item.type === 'high_spending' ? 'high' : 'medium'}">${esc(item.type.replaceAll('_', ' '))}</span><div><b>${esc(item.category)}</b><p>${esc(item.message)}</p></div></div>`).join('');
    const rows = byId('budgetPlanRows');
    if (!plan.has_history || !(plan.allocations || []).length) {
      rows.innerHTML = '<p class="muted">No category plan was generated because there is not enough historical data in the previous three months. Add real expense history and try again.</p>';
      byId('applyBudgetPlanBtn').disabled = true;
      return;
    }
    byId('applyBudgetPlanBtn').disabled = false;
    rows.innerHTML = `<div class="finance-list-row"><b>Category</b><b>Recommended limit</b><b>Previous weighted spending</b></div>` + plan.allocations.map(item => `
      <div class="finance-list-row budget-plan-edit-row">
        <b>${esc(item.category)}</b>
        <label class="budget-plan-amount"><span class="sr-only">${esc(item.category)} limit</span><input type="number" min="0.01" step="0.01" data-plan-category="${esc(item.category)}" value="${Number(item.amount).toFixed(2)}"></label>
        <span>${fmt(item.historical_weighted_spend)}</span>
      </div>`).join('') + `<p class="muted">Recommended total: ${fmt(plan.recommended_budget_total)} · Unallocated cushion: ${fmt(plan.unallocated_cushion)}. You may edit category limits before applying.</p>`;
  }

  async function applyBudgetPlan() {
    if (!currentBudgetDraft) return;
    const allocations = [...document.querySelectorAll('[data-plan-category]')].map(input => ({
      category: input.dataset.planCategory, amount: Number(input.value)
    }));
    const month = currentBudgetDraft.month;
    try {
      const result = await api('/budgets/ai-plan/apply', { method: 'POST', body: { month, allocations } });
      byId('budgetPlanPreview').style.display = 'none';
      currentBudgetDraft = null;
      showToast(`Applied ${result.categories_saved} category budgets`, 'success');
      if (window.loadBudgets) await window.loadBudgets();
      if (window.loadDashboard) await window.loadDashboard();
    } catch (e) { showToast(e.message, 'error'); }
  }

  function discardBudgetPlan() {
    currentBudgetDraft = null;
    byId('budgetPlanPreview').style.display = 'none';
    showToast('Draft discarded. No budget changes were saved.', 'info');
  }

  async function loadBudgetOptimizer() {
    const month = byId('budgetPlanMonth')?.value || currentMonth;
    const container = byId('budgetOptimizerContent');
    if (!container) return;
    try {
      const data = await api(`/budgets/optimizer?month=${encodeURIComponent(month)}`);
      const comparison = data.comparison || [];
      const recommendations = data.recommendations || [];
      const comparisonHtml = comparison.length ? `<div class="table-scroll"><table class="data-table"><thead><tr><th>Category</th><th>Budget</th><th>Actual</th><th>Variance</th></tr></thead><tbody>${comparison.map(item => `<tr><td>${esc(item.category)}</td><td>${fmt(item.budget)}</td><td>${fmt(item.actual)}</td><td class="${item.variance > 0 ? 'negative' : 'positive'}">${item.variance > 0 ? '+' : ''}${fmt(item.variance)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No saved budgets for this month. Generate and apply a budget plan first.</p>';
      const recommendationsHtml = recommendations.length ? `<h4 style="margin:18px 0 8px">Suggested reallocations</h4>${recommendations.map((item, index) => `
        <label class="optimizer-transfer"><input type="checkbox" checked data-transfer-index="${index}">
          <span><b>${esc(item.from_category)} → ${esc(item.to_category)}</b><small>${esc(item.reason)}</small></span><strong>${fmt(item.amount)}</strong></label>`).join('')}
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button class="secondary-btn" id="rejectBudgetTransfersBtn">Reject recommendations</button><button class="primary-btn" id="acceptBudgetTransfersBtn">Accept selected adjustments</button></div>` : `<p class="muted" style="margin-top:12px">No reallocation is recommended. Your saved category limits are either within budget or have no unused amount available to transfer.</p>`;
      container.innerHTML = comparisonHtml + recommendationsHtml;
      if (recommendations.length) {
        byId('rejectBudgetTransfersBtn').onclick = () => { container.innerHTML = comparisonHtml + '<p class="muted">Recommendations rejected. Your saved budgets were not changed.</p>'; };
        byId('acceptBudgetTransfersBtn').onclick = async () => {
          const selected = [...container.querySelectorAll('[data-transfer-index]:checked')].map(input => recommendations[Number(input.dataset.transferIndex)]);
          if (!selected.length) { showToast('Select at least one recommendation.', 'info'); return; }
          try {
            const result = await api('/budgets/optimizer/apply', { method: 'POST', body: { month, transfers: selected } });
            showToast(result.message, 'success');
            await loadBudgetOptimizer();
            if (window.loadBudgets) await window.loadBudgets();
          } catch (e) { showToast(e.message, 'error'); }
        };
      }
    } catch (e) {
      container.innerHTML = `<p class="negative">Unable to load optimizer: ${esc(e.message)}</p>`;
    }
  }

  async function loadExpenseInsightsModule() {
    const month = byId('expenseInsightsMonth')?.value || currentMonth;
    if (byId('expenseInsightsMonth') && !byId('expenseInsightsMonth').value) byId('expenseInsightsMonth').value = month;
    const container = byId('expenseInsightList');
    container.innerHTML = '<p class="muted">Analyzing your transactions…</p>';
    const data = await api(`/analytics/expense-insights?month=${encodeURIComponent(month)}`);
    byId('expenseInsightCount').textContent = String(data.count || 0);
    byId('expenseInsightBaseline').textContent = (data.baseline_months || []).join(' · ') || '3 months';
    if (!data.insights?.length) {
      container.innerHTML = `<div class="finance-tip-card"><span class="finance-tip-priority low">Healthy</span><div><b>No unusual patterns detected</b><p>No transactions or category totals crossed the review thresholds for ${esc(month)}. ${esc(data.message)}</p></div></div>`;
      return;
    }
    container.innerHTML = data.insights.map(item => `
      <div class="finance-tip-card expense-insight-card"><span class="finance-tip-priority ${item.severity === 'high' ? 'high' : 'medium'}">${esc(item.severity)} · ${esc(item.kind.replaceAll('_', ' '))}</span>
        <div><b>${esc(item.description || `${item.category} spending pattern`)}</b><p>${esc(item.message)}</p><small>${esc(item.date || month)} · ${esc(item.category)}${item.amount ? ` · ${fmt(item.amount)}` : ''}</small><p class="muted">${esc(item.recommendation)}</p></div></div>`).join('');
  }

  async function saveSalary() {
    try {
      await api('/finance/salary', { method: 'POST', body: {
        amount: Number(byId('salaryAmount').value),
        effective_month: byId('salaryEffectiveMonth').value
      }});
      showToast('Salary history saved. Earlier months remain unchanged.', 'success');
      await loadIncomeModule();
      await loadDashboard();
    } catch (e) { showToast(e.message, 'error'); }
  }

  async function addIncome() {
    try {
      await api('/finance/income', { method: 'POST', body: {
        income_type: byId('incomeType').value,
        amount: Number(byId('incomeAmount').value),
        description: byId('incomeDescription').value.trim(),
        transaction_date: byId('incomeDate').value
      }});
      byId('incomeAmount').value = '';
      byId('incomeDescription').value = '';
      showToast('Additional income recorded without changing salary.', 'success');
      await loadIncomeModule();
      await loadDashboard();
    } catch (e) { showToast(e.message, 'error'); }
  }

  async function saveSavingsSettings() {
    try {
      await api('/finance/savings-settings', { method: 'PUT', body: {
        enabled: byId('savingsEnabled').checked,
        method: byId('savingsMethod').value,
        value: Number(byId('savingsValue').value),
        bonus_savings_percentage: Number(byId('bonusSavingsPercentage').value)
      }});
      showToast('Automatic savings settings saved', 'success');
      await loadIncomeModule();
      await loadDashboard();
    } catch (e) { showToast(e.message, 'error'); }
  }

  async function saveNotificationSettings() {
    const browserEnabled = byId('browserNotifEnabled').checked;
    if (browserEnabled && 'Notification' in window && Notification.permission !== 'granted') {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        byId('browserNotifEnabled').checked = false;
        showToast('Browser notification permission was not granted.', 'error');
        return;
      }
    }
    try {
      await api('/finance/notification-preferences', { method: 'PUT', body: {
        daily_enabled: byId('dailyNotifEnabled').checked,
        weekly_enabled: byId('weeklyNotifEnabled').checked,
        monthly_enabled: byId('monthlyNotifEnabled').checked,
        browser_enabled: browserEnabled,
        reminder_time: byId('reminderTime').value || '09:00'
      }});
      financeBrowserNotificationsEnabled = browserEnabled;
      showToast('Reminder preferences saved', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  }

  function enableBrowserNotifications() {
    if (!('Notification' in window)) { showToast('This browser does not support notifications.', 'error'); return; }
    Notification.requestPermission().then(permission => {
      if (permission === 'granted') {
        byId('browserNotifEnabled').checked = true;
        financeBrowserNotificationsEnabled = true;
        showToast('Browser notifications allowed. Save your reminder settings.', 'success');
      } else showToast('Browser notification permission was not granted.', 'error');
    });
  }

  document.addEventListener('DOMContentLoaded', () => {});
  byId('financeMonth')?.addEventListener('change', () => {
    if (byId('salaryEffectiveMonth')) byId('salaryEffectiveMonth').value = byId('financeMonth').value;
    loadIncomeModule().catch(e => showToast(e.message, 'error'));
  });
  byId('predictionMonth')?.addEventListener('change', () => loadBudgetPredictionModule().catch(e => showToast(e.message, 'error')));
  byId('saveSalaryBtn')?.addEventListener('click', saveSalary);
  byId('addIncomeBtn')?.addEventListener('click', addIncome);
  byId('saveSavingsSettingsBtn')?.addEventListener('click', saveSavingsSettings);
  byId('saveNotifSettingsBtn')?.addEventListener('click', saveNotificationSettings);
  byId('enableBrowserNotificationsBtn')?.addEventListener('click', enableBrowserNotifications);
  byId('refreshPredictionBtn')?.addEventListener('click', () => loadBudgetPredictionModule().catch(e => showToast(e.message, 'error')));
  byId('refreshSavingTipsBtn')?.addEventListener('click', () => loadSavingTips(true));
  byId('generateBudgetPlanBtn')?.addEventListener('click', generateBudgetPlan);
  byId('applyBudgetPlanBtn')?.addEventListener('click', applyBudgetPlan);
  byId('discardBudgetPlanBtn')?.addEventListener('click', discardBudgetPlan);
  byId('budgetPlanMonth')?.addEventListener('change', () => {
    if (window.loadBudgets) window.loadBudgets().catch(e => showToast(e.message, 'error'));
    if (currentBudgetDraft) discardBudgetPlan();
  });
  byId('refreshBudgetOptimizerBtn')?.addEventListener('click', () => loadBudgetOptimizer());
  byId('refreshExpenseInsightsBtn')?.addEventListener('click', () => loadExpenseInsightsModule().catch(e => showToast(e.message, 'error')));
  byId('expenseInsightsMonth')?.addEventListener('change', () => loadExpenseInsightsModule().catch(e => showToast(e.message, 'error')));

  // Expose functions used by the existing page navigation and polling system.
  window.loadIncomeModule = loadIncomeModule;
  window.loadBudgetPredictionModule = loadBudgetPredictionModule;
  window.loadSavingTips = loadSavingTips;
  window.loadBudgetOptimizer = loadBudgetOptimizer;
  window.loadExpenseInsightsModule = loadExpenseInsightsModule;

  // Pre-fill date inputs before the user opens the new modules.
  if (byId('financeMonth') && !byId('financeMonth').value) byId('financeMonth').value = currentMonth;
  if (byId('predictionMonth') && !byId('predictionMonth').value) byId('predictionMonth').value = currentMonth;
  if (byId('budgetPlanMonth') && !byId('budgetPlanMonth').value) byId('budgetPlanMonth').value = currentMonth;
  if (byId('expenseInsightsMonth') && !byId('expenseInsightsMonth').value) byId('expenseInsightsMonth').value = currentMonth;
  if (byId('transactionMonth') && !byId('transactionMonth').value) byId('transactionMonth').value = currentMonth;
  if (byId('salaryEffectiveMonth') && !byId('salaryEffectiveMonth').value) byId('salaryEffectiveMonth').value = currentMonth;
  if (byId('incomeDate') && !byId('incomeDate').value) byId('incomeDate').value = currentDate;
})();
