-- FinSight AI finance upgrade. All statements are idempotent.
CREATE TABLE IF NOT EXISTS salary_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    effective_from DATE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_salary_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_salary_user_effective (user_id, effective_from),
    INDEX idx_salary_effective (user_id, effective_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS income_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    income_type VARCHAR(30) NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    transaction_date DATE NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_income_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_income_user_date (user_id, transaction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS savings_settings (
    user_id INT PRIMARY KEY,
    savings_method VARCHAR(20) NOT NULL DEFAULT 'percentage',
    savings_value DECIMAL(12,2) NOT NULL DEFAULT 20.00,
    bonus_savings_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_savings_settings_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS monthly_savings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    month CHAR(7) NOT NULL,
    salary_income DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    additional_income DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    reserved_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_monthly_savings_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_monthly_savings_user_month (user_id, month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notification_preferences (
    user_id INT PRIMARY KEY,
    daily_enabled TINYINT(1) NOT NULL DEFAULT 1,
    weekly_enabled TINYINT(1) NOT NULL DEFAULT 1,
    monthly_enabled TINYINT(1) NOT NULL DEFAULT 1,
    browser_enabled TINYINT(1) NOT NULL DEFAULT 0,
    reminder_time TIME NOT NULL DEFAULT '09:00:00',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_preferences_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    notification_type VARCHAR(40) NOT NULL,
    title VARCHAR(160) NOT NULL,
    message VARCHAR(500) NOT NULL,
    dedupe_key VARCHAR(120) NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_notification_dedupe (user_id, dedupe_key),
    INDEX idx_user_notifications (user_id, is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Preserve the legacy monthly_income as the initial salary from the month the upgrade is installed.
-- Older salary history must be entered by the user because the legacy schema did not store it.
INSERT IGNORE INTO salary_history (user_id, amount, effective_from)
SELECT id, GREATEST(COALESCE(monthly_income, 0), 0), DATE_FORMAT(CURDATE(), '%Y-%m-01')
FROM users;

INSERT IGNORE INTO savings_settings (user_id)
SELECT id FROM users;

INSERT IGNORE INTO notification_preferences (user_id)
SELECT id FROM users;
