"""History-weighted budget allocation using the existing expense prediction model."""
from datetime import date
DEFAULT_CATEGORIES = ['Food', 'Travel', 'Shopping', 'Bills', 'Entertainment', 'Other']


def allocate_budget(spendable_budget, category_weights):
    """Allocate a spendable amount proportionally, preserving the exact total."""
    spendable_budget = round(float(spendable_budget), 2)
    weights = {str(category): max(float(weight), 0.0) for category, weight in category_weights.items()}
    total_weight = sum(weights.values())
    if total_weight <= 0:
        weights = {category: 1.0 for category in DEFAULT_CATEGORIES}
        total_weight = float(len(DEFAULT_CATEGORIES))

    active = [category for category, weight in weights.items() if weight > 0]
    allocations = {}
    assigned = 0.0
    for category in active[:-1]:
        amount = round(spendable_budget * weights[category] / total_weight, 2)
        allocations[category] = amount
        assigned += amount
    if active:
        allocations[active[-1]] = round(spendable_budget - assigned, 2)
    return allocations, weights


def recommend_budget(user_id, monthly_budget, savings_reserve=0.0):
    from db import query_all
    from ml import predictor
    monthly_budget = round(float(monthly_budget), 2)
    savings_reserve = round(float(savings_reserve), 2)
    if monthly_budget <= 0:
        raise ValueError('Monthly budget must be greater than zero')
    if savings_reserve < 0 or savings_reserve > monthly_budget:
        raise ValueError('Savings reserve must be between zero and the monthly budget')

    today = date.today()
    month_keys = []
    for offset in range(5, -1, -1):
        year, month = today.year, today.month - offset
        while month <= 0:
            year -= 1
            month += 12
        month_keys.append(f'{year}-{month:02d}')

    rows = query_all(
        """SELECT e.category, DATE_FORMAT(e.date, '%Y-%m') AS month,
                  SUM(es.amount) AS total
           FROM expense_splits es
           JOIN expenses e ON e.id = es.expense_id
           WHERE es.user_id = %s AND e.date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
           GROUP BY e.category, DATE_FORMAT(e.date, '%Y-%m')""",
        (user_id,),
    )
    history = {}
    for row in rows:
        history.setdefault(row['category'] or 'Other', {month: 0.0 for month in month_keys})
        if row['month'] in history[row['category'] or 'Other']:
            history[row['category'] or 'Other'][row['month']] = float(row['total'] or 0)

    categories = list(dict.fromkeys(DEFAULT_CATEGORIES + list(history.keys())))
    category_history = {category: [history.get(category, {}).get(month, 0.0) for month in month_keys] for category in categories}
    predictions = predictor.predict_category_wise(category_history)
    weights = {category: max(float(predictions.get(category, {}).get('prediction', 0)), 0) for category in categories}
    spendable = round(monthly_budget - savings_reserve, 2)
    allocations, weights = allocate_budget(spendable, weights)

    return {
        'monthly_budget': monthly_budget,
        'savings_reserve': savings_reserve,
        'spendable_budget': spendable,
        'allocations': [
            {
                'category': category,
                'amount': amount,
                'percentage': round(amount / monthly_budget * 100, 1) if monthly_budget else 0,
                'predicted_historical_spend': round(weights.get(category, 0), 2),
            }
            for category, amount in sorted(allocations.items(), key=lambda item: item[1], reverse=True)
        ],
        'method': 'Proportional allocation based on the existing ML model\'s category-wise spending forecasts; savings are reserved first.',
        'history_months': month_keys,
    }


def generate_three_month_budget_plan(user_id, target_month):
    """Create a review-only budget draft using the prior three complete months.

    This function never writes budgets. The caller must explicitly apply the plan.
    """
    from services.finance_service import (
        validate_month, shift_month, get_month_financial_summary,
        get_month_expenses,
    )

    target_month = validate_month(target_month)
    history_months = [shift_month(target_month, offset) for offset in (-3, -2, -1)]
    categories = list(DEFAULT_CATEGORIES)
    monthly_category_data = {}
    for month in history_months:
        _, monthly = get_month_expenses(user_id, month)
        for category in monthly:
            if category not in categories:
                categories.append(category)
        monthly_category_data[month] = monthly

    from ml.predictor import BudgetPredictor
    model = BudgetPredictor()
    category_history = {category: [float(monthly_category_data[m].get(category, 0.0)) for m in history_months] for category in categories}
    model_predictions = model.predict_category_wise(category_history)
    weighted_forecast = {}
    insights = []
    has_history = any(sum(monthly_category_data[m].values()) > 0 for m in history_months)
    confidence_values = []
    for category in categories:
        values = category_history[category]
        forecast = round(float(model_predictions.get(category, {}).get('prediction', 0.0)), 2)
        if forecast > 0:
            weighted_forecast[category] = forecast
        if any(values):
            confidence_values.append(float(model_predictions.get(category, {}).get('confidence', 0.0)))
        avg = sum(values) / 3.0
        latest = values[-1]
        if avg > 0 and latest > avg * 1.25:
            increase_pct = round((latest - avg) / avg * 100)
            insights.append({
                'category': category,
                'type': 'high_spending',
                'message': f'{category} spending in {history_months[-1]} was {increase_pct}% above its three-month average.'
            })

    summary = get_month_financial_summary(user_id, target_month)
    total_income = float(summary['total_income'])
    savings_reserve = float(summary['automatic_savings'])
    spendable = max(total_income - savings_reserve, 0.0)

    predicted_total = sum(weighted_forecast.values())
    recommended_total = min(spendable, round(predicted_total * 1.05, 2)) if has_history else 0.0
    allocations = {}
    if recommended_total > 0 and predicted_total > 0:
        remaining = recommended_total
        active = list(weighted_forecast)
        for category in active[:-1]:
            amount = round(recommended_total * weighted_forecast[category] / predicted_total, 2)
            allocations[category] = amount
            remaining -= amount
        allocations[active[-1]] = round(remaining, 2)

    for category, amount in allocations.items():
        if weighted_forecast.get(category, 0) > amount:
            insights.append({
                'category': category,
                'type': 'budget_cap',
                'message': f'The available spendable budget requires a tighter {category} limit than the historical forecast.'
            })

    return {
        'month': target_month,
        'history_months': history_months,
        'salary_income': round(float(summary['salary_income']), 2),
        'additional_income': round(float(summary['additional_income']), 2),
        'total_income': round(total_income, 2),
        'automatic_savings': round(savings_reserve, 2),
        'spendable_budget': round(spendable, 2),
        'predicted_expenses': round(predicted_total, 2),
        'recommended_budget_total': round(sum(allocations.values()), 2),
        'unallocated_cushion': round(max(spendable - sum(allocations.values()), 0), 2),
        'allocations': [
            {'category': category, 'amount': round(amount, 2),
             'historical_weighted_spend': round(weighted_forecast[category], 2),
             'percentage': round(amount / spendable * 100, 1) if spendable else 0}
            for category, amount in sorted(allocations.items(), key=lambda item: item[1], reverse=True)
        ],
        'insights': insights,
        'has_history': has_history,
        'forecast_confidence': round(sum(confidence_values) / len(confidence_values), 2) if confidence_values else 0.0,
        'generated_by': 'Three-month WMA + Linear Trend ML forecast',
        'explanation': (
            'The plan uses the previous three completed months, weighting the most recent month highest. '
            'It retrieves the target month salary and one-time income, reserves automatic savings first, '
            'then allocates a 5% planning buffer across categories. The existing WMA + Linear Trend model produces the category forecasts. This is a draft only; no budget is saved until Apply Budget is selected.'
        ) if has_history else (
            'There is not enough historical expense data in the three preceding months to create a reliable plan. '
            'Add real dated transactions first. No category limits have been invented.'
        ),
    }


def build_budget_optimizer(user_id, month):
    """Compare saved category budgets with actual spending and suggest transfers."""
    from models.budget import get_budgets, recalculate_spent
    budgets = get_budgets(user_id, month)
    for budget in budgets:
        recalculate_spent(user_id, budget['category'], month)
    budgets = get_budgets(user_id, month)

    overages = []
    sources = []
    for budget in budgets:
        spent = float(budget['spent'])
        limit = float(budget['limit'])
        if spent > limit:
            overages.append({'category': budget['category'], 'amount': round(spent - limit, 2), 'spent': spent, 'limit': limit})
        elif limit > spent:
            sources.append({'category': budget['category'], 'remaining': round(limit - spent, 2), 'spent': spent, 'limit': limit})

    transfers = []
    for target in sorted(overages, key=lambda item: item['amount'], reverse=True):
        outstanding = target['amount']
        for source in sorted(sources, key=lambda item: item['remaining'], reverse=True):
            if outstanding <= 0.009:
                break
            if source['category'] == target['category'] or source['remaining'] <= 0.009:
                continue
            amount = round(min(outstanding, source['remaining']), 2)
            if amount <= 0:
                continue
            transfers.append({
                'from_category': source['category'],
                'to_category': target['category'],
                'amount': amount,
                'reason': f"{target['category']} is over budget by {target['amount']:.2f}; {source['category']} has unspent planned budget."
            })
            source['remaining'] = round(source['remaining'] - amount, 2)
            outstanding = round(outstanding - amount, 2)

    comparison = [{
        'category': b['category'], 'budget': round(float(b['limit']), 2),
        'actual': round(float(b['spent']), 2),
        'variance': round(float(b['spent']) - float(b['limit']), 2),
        'remaining': round(max(float(b['limit']) - float(b['spent']), 0), 2),
        'status': 'over' if float(b['spent']) > float(b['limit']) else 'within'
    } for b in budgets]
    return {
        'month': month, 'comparison': comparison, 'recommendations': transfers,
        'message': 'Suggested transfers preserve the overall planned budget. Accept to update category limits, or reject by leaving the plan unapplied.'
    }
