"""Local-app reminder scheduler. In-app reminders persist in MySQL."""
from datetime import datetime
from db import query_all, execute
from services.finance_service import get_month_financial_summary, get_month_expenses


def _time_hhmm(value):
    if hasattr(value, 'strftime'):
        return value.strftime('%H:%M')
    parts = str(value or '09:00:00').split(':')
    return f'{int(parts[0]):02d}:{int(parts[1]):02d}' if len(parts) >= 2 else '09:00'


def _insert(user_id, kind, title, message, dedupe_key):
    execute(
        """INSERT IGNORE INTO user_notifications
           (user_id, notification_type, title, message, dedupe_key)
           VALUES (%s, %s, %s, %s, %s)""",
        (user_id, kind, title[:160], message[:500], dedupe_key[:120]),
    )


def generate_scheduled_notifications():
    """Run every minute; unique keys prevent duplicate reminders."""
    now = datetime.now()
    month = now.strftime('%Y-%m')
    clock = now.strftime('%H:%M')
    today_key = now.strftime('%Y%m%d')
    rows = query_all('SELECT * FROM notification_preferences')
    for row in rows:
        user_id = row['user_id']
        configured_time = _time_hhmm(row['reminder_time'])
        if clock < configured_time:
            continue

        if row['daily_enabled']:
            try:
                summary = get_month_financial_summary(user_id, month)
                reserve = summary['automatic_savings']
                message = (
                    f"Your planned savings reserve for {now.strftime('%B')} is ₹{reserve:,.0f}. "
                    "Check today's purchases against your monthly budget."
                )
            except Exception:
                message = "Take a moment to review today's spending and keep your savings target on track."
            _insert(user_id, 'daily_saving', 'Your daily FinSight reminder', message, f'daily-saving-{today_key}')

        if row['weekly_enabled'] and now.weekday() == 0:
            _insert(
                user_id, 'weekly_review', 'Weekly budget check-in',
                'Review your category spending, upcoming bills and remaining monthly budget for the week.',
                f'weekly-review-{now.strftime("%G%V")}',
            )

        if row['monthly_enabled'] and now.day == 1:
            _insert(
                user_id, 'monthly_summary', 'New month, fresh budget',
                'Review your salary, any additional income, automatic savings reserve and category budgets for this month.',
                f'monthly-review-{month}',
            )

        # One notification per category and month for 80% and 100% budget thresholds.
        budgets = query_all(
            'SELECT category, limit_amount FROM budgets WHERE user_id = %s AND month = %s',
            (user_id, month),
        )
        _, category_spend = get_month_expenses(user_id, month)
        for budget in budgets:
            limit = float(budget['limit_amount'] or 0)
            spent = float(category_spend.get(budget['category'], 0))
            if limit <= 0:
                continue
            pct = spent / limit * 100
            if pct >= 100:
                _insert(
                    user_id, 'budget_exceeded', f'{budget["category"]} budget exceeded',
                    f'You have spent ₹{spent:,.0f} against a ₹{limit:,.0f} {budget["category"]} budget.',
                    f'budget-100-{month}-{budget["category"]}',
                )
            elif pct >= 80:
                _insert(
                    user_id, 'budget_warning', f'{budget["category"]} budget warning',
                    f'You have used {pct:.0f}% of your ₹{limit:,.0f} {budget["category"]} budget.',
                    f'budget-80-{month}-{budget["category"]}',
                )


def start_reminder_scheduler():
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
    except ImportError:
        print('APScheduler not installed; scheduled reminders are disabled.')
        return None
    scheduler = BackgroundScheduler(timezone='Asia/Kolkata')
    scheduler.add_job(generate_scheduled_notifications, 'interval', minutes=1,
                      id='finance-reminders', replace_existing=True, max_instances=1)
    scheduler.start()
    print('🔔 FinSight financial reminders scheduled (every minute).')
    return scheduler
