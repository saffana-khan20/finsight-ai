"""Income history, savings reservations and month-aware budget forecasts."""
from __future__ import annotations

from datetime import date, datetime
from calendar import monthrange
from collections import defaultdict
from db import query_one, query_all, execute
from ml.predictor import BudgetPredictor

CATEGORIES = ['Food', 'Travel', 'Shopping', 'Bills', 'Entertainment', 'Other']
_predictor = BudgetPredictor()


def validate_month(value: str | None) -> str:
    if not value:
        return date.today().strftime('%Y-%m')
    try:
        parsed = datetime.strptime(value, '%Y-%m')
        return parsed.strftime('%Y-%m')
    except (TypeError, ValueError):
        raise ValueError('Month must use YYYY-MM format')


def month_start(month: str) -> date:
    return datetime.strptime(validate_month(month), '%Y-%m').date().replace(day=1)


def month_end_exclusive(month: str) -> date:
    start = month_start(month)
    year, mon = start.year, start.month
    if mon == 12:
        return date(year + 1, 1, 1)
    return date(year, mon + 1, 1)


def shift_month(month: str, offset: int) -> str:
    start = month_start(month)
    idx = start.year * 12 + (start.month - 1) + offset
    year, zero_month = divmod(idx, 12)
    return f'{year:04d}-{zero_month + 1:02d}'


def get_salary_for_month(user_id: int, month: str) -> float:
    row = query_one(
        """SELECT amount FROM salary_history
           WHERE user_id = %s AND effective_from <= %s
           ORDER BY effective_from DESC LIMIT 1""",
        (user_id, month_start(month)),
    )
    return round(float(row['amount']), 2) if row else 0.0


def get_additional_income(user_id: int, month: str) -> tuple[float, list[dict]]:
    rows = query_all(
        """SELECT id, income_type, description, amount, transaction_date, notes
           FROM income_transactions
           WHERE user_id = %s AND transaction_date >= %s AND transaction_date < %s
           ORDER BY transaction_date DESC, id DESC""",
        (user_id, month_start(month), month_end_exclusive(month)),
    )
    items = []
    total = 0.0
    for row in rows:
        amount = round(float(row['amount']), 2)
        total += amount
        items.append({
            'id': row['id'], 'income_type': row['income_type'],
            'description': row['description'], 'amount': amount,
            'transaction_date': row['transaction_date'].isoformat(),
            'notes': row.get('notes') or '',
        })
    return round(total, 2), items


def get_month_expenses(user_id: int, month: str) -> tuple[float, dict[str, float]]:
    rows = query_all(
        """SELECT COALESCE(e.category, 'Other') AS category,
                  COALESCE(SUM(es.amount), 0) AS total
           FROM expense_splits es
           JOIN expenses e ON e.id = es.expense_id
           WHERE es.user_id = %s AND e.date >= %s AND e.date < %s
           GROUP BY COALESCE(e.category, 'Other')""",
        (user_id, month_start(month), month_end_exclusive(month)),
    )
    categories = {str(r['category'] or 'Other'): round(float(r['total'] or 0), 2) for r in rows}
    return round(sum(categories.values()), 2), categories


def get_savings_settings(user_id: int) -> dict:
    row = query_one("SELECT * FROM savings_settings WHERE user_id = %s", (user_id,))
    if not row:
        execute("INSERT IGNORE INTO savings_settings (user_id) VALUES (%s)", (user_id,))
        row = query_one("SELECT * FROM savings_settings WHERE user_id = %s", (user_id,))
    return {
        'method': row['savings_method'], 'value': float(row['savings_value']),
        'bonus_savings_percentage': float(row['bonus_savings_percentage']),
        'enabled': bool(row['enabled']),
    }


def calculate_savings_reserve(user_id: int, month: str, salary: float, additional_income: float) -> dict:
    # Past months keep their saved allocation snapshot. Browsing history must not
    # silently rewrite what the user had previously planned to save.
    current_month = date.today().strftime('%Y-%m')
    existing = query_one(
        'SELECT reserved_amount FROM monthly_savings WHERE user_id = %s AND month = %s',
        (user_id, month),
    )
    settings = get_savings_settings(user_id)
    if month < current_month and existing:
        reserved = round(float(existing['reserved_amount']), 2)
        return {
            'reserved_amount': reserved,
            'salary_component': reserved,
            'bonus_component': 0.0,
            'settings': settings,
        }

    if not settings['enabled']:
        planned = 0.0
    elif settings['method'] == 'fixed':
        planned = settings['value']
    else:
        planned = salary * settings['value'] / 100.0
    bonus_reserve = additional_income * settings['bonus_savings_percentage'] / 100.0
    reserved = round(min(max(planned + bonus_reserve, 0), salary + additional_income), 2)
    if month < current_month:
        execute(
            'INSERT IGNORE INTO monthly_savings (user_id, month, salary_income, additional_income, reserved_amount) VALUES (%s, %s, %s, %s, %s)',
            (user_id, month, salary, additional_income, reserved),
        )
    else:
        execute(
            """INSERT INTO monthly_savings
               (user_id, month, salary_income, additional_income, reserved_amount)
               VALUES (%s, %s, %s, %s, %s)
               ON DUPLICATE KEY UPDATE salary_income = VALUES(salary_income),
                 additional_income = VALUES(additional_income), reserved_amount = VALUES(reserved_amount)""",
            (user_id, month, salary, additional_income, reserved),
        )
    return {
        'reserved_amount': reserved,
        'salary_component': round(min(planned, salary + additional_income), 2),
        'bonus_component': round(min(bonus_reserve, salary + additional_income), 2),
        'settings': settings,
    }


def get_month_financial_summary(user_id: int, month: str) -> dict:
    month = validate_month(month)
    salary = get_salary_for_month(user_id, month)
    additional, income_items = get_additional_income(user_id, month)
    total_expenses, category_expenses = get_month_expenses(user_id, month)
    total_income = round(salary + additional, 2)
    savings = calculate_savings_reserve(user_id, month, salary, additional)
    spendable = round(max(total_income - savings['reserved_amount'], 0), 2)
    return {
        'month': month,
        'salary_income': salary,
        'additional_income': additional,
        'total_income': total_income,
        'income_transactions': income_items,
        'total_expenses': total_expenses,
        'category_expenses': category_expenses,
        'automatic_savings': savings['reserved_amount'],
        'spendable_budget': spendable,
        'unallocated_after_expenses': round(spendable - total_expenses, 2),
        'savings_settings': savings['settings'],
    }


def get_month_history(user_id: int, months: int = 2, end_month: str | None = None) -> list[dict]:
    end_month = validate_month(end_month)
    months = max(2, min(int(months or 2), 12))
    result = []
    for offset in range(months - 1, -1, -1):
        key = shift_month(end_month, -offset)
        result.append(get_month_financial_summary(user_id, key))
    return result


def get_expense_history(user_id: int, target_month: str, months: int = 6) -> tuple[list[str], dict[str, list[float]]]:
    target_month = validate_month(target_month)
    months = max(2, min(months, 12))
    month_keys = [shift_month(target_month, -i) for i in range(months, 0, -1)]
    start_date = month_start(month_keys[0])
    end_date = month_start(target_month)
    rows = query_all(
        """SELECT COALESCE(e.category, 'Other') AS category,
                  DATE_FORMAT(e.date, '%Y-%m') AS month,
                  COALESCE(SUM(es.amount), 0) AS total
           FROM expense_splits es
           JOIN expenses e ON e.id = es.expense_id
           WHERE es.user_id = %s AND e.date >= %s AND e.date < %s
           GROUP BY COALESCE(e.category, 'Other'), DATE_FORMAT(e.date, '%Y-%m')""",
        (user_id, start_date, end_date),
    )
    history = {category: {month: 0.0 for month in month_keys} for category in CATEGORIES}
    for row in rows:
        category = row['category'] or 'Other'
        history.setdefault(category, {month: 0.0 for month in month_keys})
        if row['month'] in history[category]:
            history[category][row['month']] = float(row['total'] or 0)
    return month_keys, {category: [round(history[category][m], 2) for m in month_keys] for category in history}


def build_budget_prediction(user_id: int, target_month: str) -> dict:
    target_month = validate_month(target_month)
    month_keys, category_history = get_expense_history(user_id, target_month, 6)
    category_predictions = _predictor.predict_category_wise(category_history)
    category_forecasts = {
        category: round(float(item.get('prediction', 0)), 2)
        for category, item in category_predictions.items()
    }
    predicted_expenses = round(sum(category_forecasts.values()), 2)
    summary = get_month_financial_summary(user_id, target_month)
    spendable = summary['spendable_budget']

    # Forecasts remain driven by expenses. A salary increase changes available budget,
    # savings reserve and allocation headroom, not historical spending evidence.
    weights = {c: max(v, 0.0) for c, v in category_forecasts.items()}
    total_weight = sum(weights.values())
    has_history_forecast = total_weight > 0
    # Recommend predicted category spend plus a modest 10% buffer, capped by
    # spendable income. With no expense history, do not invent category limits.
    recommended_total = min(spendable, round(predicted_expenses * 1.10, 2)) if has_history_forecast else 0.0
    allocations = {}
    assigned = 0.0
    active = [c for c, w in weights.items() if w > 0]
    for category in active[:-1]:
        amount = round(recommended_total * weights[category] / total_weight, 2)
        allocations[category] = amount
        assigned += amount
    if active:
        allocations[active[-1]] = round(recommended_total - assigned, 2)

    forecast_confidence = min(
        (category_predictions[c]['confidence'] for c in category_predictions),
        default=0.0,
    )
    actual_expenses, actual_categories = get_month_expenses(user_id, target_month)
    remaining_after_forecast = round(spendable - predicted_expenses, 2)
    return {
        **summary,
        'predicted_expenses': predicted_expenses,
        'predicted_savings_after_expenses': round(max(remaining_after_forecast, 0), 2),
        'forecast_confidence': round(float(forecast_confidence), 2),
        'has_forecast_data': has_history_forecast,
        'trend': _predictor.predict_next_month([sum(category_history[c][i] for c in category_history) for i in range(len(month_keys))]),
        'history_months': month_keys,
        'category_predictions': category_forecasts,
        'category_allocations': allocations,
        'recommended_budget_total': round(sum(allocations.values()), 2),
        'unallocated_spendable_budget': round(max(spendable - sum(allocations.values()), 0), 2),
        'forecast_over_spendable_budget': round(max(predicted_expenses - spendable, 0), 2),
        'actual_expenses_to_date': actual_expenses,
        'actual_category_spending': actual_categories,
        'note': ('Predictions use historical category spending. Salary changes affect the available budget and savings reserve; bonuses are treated as one-time income.' if has_history_forecast else 'There is not enough historical expense data to create category predictions yet. Add dated expenses from prior months; no category limits have been invented.'),
    }


def generate_saving_tips(user_id: int, month: str) -> dict:
    """Use Gemini for personalized wording when configured; safely fall back to rules."""
    prediction = build_budget_prediction(user_id, month)
    history = get_month_history(user_id, 2, month)
    tips = []
    current = history[-1]
    previous = history[-2] if len(history) > 1 else None
    category_spending = current['category_expenses']
    ranked = sorted(category_spending.items(), key=lambda item: item[1], reverse=True)
    if ranked and ranked[0][1] > 0:
        tips.append({
            'title': f'Review {ranked[0][0]} spending',
            'message': f'{ranked[0][0]} is currently your highest spending category at ₹{ranked[0][1]:,.0f}. Set a weekly limit and review purchases before spending.',
            'category': ranked[0][0], 'priority': 'high'
        })
    if previous and current['total_expenses'] > previous['total_expenses']:
        change = current['total_expenses'] - previous['total_expenses']
        tips.append({
            'title': 'Watch the month-on-month increase',
            'message': f'Your recorded expenses are ₹{change:,.0f} higher than {previous["month"]}. Check which categories caused the increase.',
            'category': 'Overall', 'priority': 'medium'
        })
    if current['automatic_savings'] > 0:
        tips.append({
            'title': 'Protect your savings reserve',
            'message': f'Your planned automatic savings are ₹{current["automatic_savings"]:,.0f}. Treat this amount as unavailable for everyday spending.',
            'category': 'Savings', 'priority': 'high'
        })
    if prediction['predicted_expenses'] > prediction['spendable_budget']:
        tips.append({
            'title': 'Forecast is above your spendable budget',
            'message': f'Predicted expenses are ₹{prediction["predicted_expenses"]:,.0f}, about ₹{prediction["predicted_expenses"] - prediction["spendable_budget"]:,.0f} above the spendable budget. Review discretionary categories.',
            'category': 'Budget', 'priority': 'high'
        })
    if not tips:
        tips.append({
            'title': 'Build consistent savings habits',
            'message': 'Review your planned savings reserve each payday and check your category budgets once a week.',
            'category': 'Savings', 'priority': 'low'
        })

    api_key = __import__('os').environ.get('GEMINI_API_KEY') or __import__('os').environ.get('GOOGLE_API_KEY')
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            context = {
                'month': month,
                'salary': current['salary_income'],
                'additional_income': current['additional_income'],
                'expenses': current['total_expenses'],
                'category_spending': current['category_expenses'],
                'automatic_savings': current['automatic_savings'],
                'predicted_expenses': prediction['predicted_expenses'],
                'spendable_budget': prediction['spendable_budget'],
                'previous_month': previous,
            }
            response = client.models.generate_content(
                model=__import__('os').environ.get('GEMINI_MODEL', 'gemini-2.5-flash'),
                contents='Give 3 concise, specific, non-judgmental ways to improve this monthly budget. Use only these figures. Return JSON array of objects with title, message, category, priority. Do not give investment or debt advice. Financial data: ' + str(context),
                config={'temperature': 0.2},
            )
            import json
            text = (response.text or '').strip()
            text = text.removeprefix('```json').removesuffix('```').strip()
            generated = json.loads(text)
            if isinstance(generated, list) and generated:
                clean = []
                for item in generated[:5]:
                    if isinstance(item, dict) and item.get('title') and item.get('message'):
                        clean.append({
                            'title': str(item['title'])[:120],
                            'message': str(item['message'])[:500],
                            'category': str(item.get('category', 'General'))[:50],
                            'priority': str(item.get('priority', 'medium'))[:20],
                        })
                if clean:
                    tips = clean
                    return {'tips': tips, 'generated_by': 'Gemini AI', 'month': month}
        except Exception:
            pass
    return {'tips': tips, 'generated_by': 'Rule-based financial analysis', 'month': month}
