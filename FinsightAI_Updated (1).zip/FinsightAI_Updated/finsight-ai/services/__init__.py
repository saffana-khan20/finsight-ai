"""FinSight AI background services."""
