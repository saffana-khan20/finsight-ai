"""Personal income, history, automatic savings, budget prediction and reminders APIs."""
from datetime import date, datetime
import re
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from db import query_one, query_all, execute
from services.finance_service import (
    validate_month, month_start, get_month_financial_summary,
    get_month_history, build_budget_prediction, generate_saving_tips,
    get_savings_settings,
)

finance_bp = Blueprint('finance', __name__)
MONTH_RE = re.compile(r'^\d{4}-\d{2}$')


def _json_error(message, status=400):
    return jsonify({'error': message}), status


def _format_time(value):
    if hasattr(value, 'strftime'):
        return value.strftime('%H:%M')
    raw = str(value or '09:00:00')
    parts = raw.split(':')
    return f'{int(parts[0]):02d}:{int(parts[1]):02d}' if len(parts) >= 2 else '09:00'


@finance_bp.route('/income', methods=['GET'])
@login_required
def income_for_month():
    try:
        month = validate_month(request.args.get('month'))
        salary_row = query_one(
            """SELECT amount, effective_from FROM salary_history
               WHERE user_id = %s AND effective_from <= %s
               ORDER BY effective_from DESC LIMIT 1""",
            (current_user.id, month_start(month)),
        )
        salary_history = query_all(
            """SELECT id, amount, effective_from FROM salary_history
               WHERE user_id = %s ORDER BY effective_from DESC LIMIT 12""",
            (current_user.id,),
        )
        summary = get_month_financial_summary(current_user.id, month)
        return jsonify({
            'month': month,
            'salary': {
                'amount': summary['salary_income'],
                'effective_from': salary_row['effective_from'].isoformat() if salary_row else None,
            },
            'salary_history': [
                {'id': r['id'], 'amount': float(r['amount']), 'effective_from': r['effective_from'].isoformat()}
                for r in salary_history
            ],
            'income_transactions': summary['income_transactions'],
            'additional_income': summary['additional_income'],
            'total_income': summary['total_income'],
        })
    except ValueError as exc:
        return _json_error(str(exc))


@finance_bp.route('/salary', methods=['POST'])
@login_required
def add_salary_record():
    data = request.get_json(silent=True) or {}
    try:
        amount = round(float(data.get('amount')), 2)
        effective_month = validate_month(data.get('effective_month'))
        if amount < 0 or amount > 100_000_000:
            return _json_error('Salary must be between 0 and 100,000,000')
        effective_from = month_start(effective_month)
        execute(
            """INSERT INTO salary_history (user_id, amount, effective_from)
               VALUES (%s, %s, %s)
               ON DUPLICATE KEY UPDATE amount = VALUES(amount)""",
            (current_user.id, amount, effective_from),
        )
        current_month = date.today().strftime('%Y-%m')
        if effective_month <= current_month:
            execute('UPDATE users SET monthly_income = %s WHERE id = %s', (amount, current_user.id))
        execute('DELETE FROM monthly_savings WHERE user_id = %s AND month >= %s', (current_user.id, effective_month))
        return jsonify({'message': 'Salary history saved', 'month': effective_month, 'amount': amount})
    except (TypeError, ValueError) as exc:
        return _json_error(str(exc) or 'Enter a valid salary and effective month')


@finance_bp.route('/income', methods=['POST'])
@login_required
def add_income():
    data = request.get_json(silent=True) or {}
    income_type = (data.get('income_type') or '').strip().lower()
    if income_type not in {'bonus', 'incentive', 'other'}:
        return _json_error('Income type must be bonus, incentive or other. Salary is recorded separately.')
    try:
        amount = round(float(data.get('amount')), 2)
    except (TypeError, ValueError):
        return _json_error('Enter a valid amount')
    if amount <= 0 or amount > 100_000_000:
        return _json_error('Amount must be greater than zero and within the allowed limit')
    description = (data.get('description') or income_type.title()).strip()[:255]
    try:
        tx_date = date.fromisoformat(data.get('transaction_date') or date.today().isoformat())
    except ValueError:
        return _json_error('Transaction date must use YYYY-MM-DD format')
    notes = (data.get('notes') or '')[:1000]
    item_id = execute(
        """INSERT INTO income_transactions
           (user_id, income_type, description, amount, transaction_date, notes)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (current_user.id, income_type, description, amount, tx_date, notes),
    )
    execute('DELETE FROM monthly_savings WHERE user_id = %s AND month = %s', (current_user.id, tx_date.strftime('%Y-%m')))
    return jsonify({'message': 'Additional income saved', 'id': item_id}), 201


@finance_bp.route('/income/<int:item_id>', methods=['DELETE'])
@login_required
def delete_income(item_id):
    row = query_one('SELECT id, transaction_date FROM income_transactions WHERE id = %s AND user_id = %s', (item_id, current_user.id))
    if not row:
        return _json_error('Income record not found', 404)
    execute('DELETE FROM income_transactions WHERE id = %s AND user_id = %s', (item_id, current_user.id))
    execute('DELETE FROM monthly_savings WHERE user_id = %s AND month = %s', (current_user.id, row['transaction_date'].strftime('%Y-%m')))
    return jsonify({'message': 'Income record deleted'})


@finance_bp.route('/history', methods=['GET'])
@login_required
def financial_history():
    try:
        months = int(request.args.get('months', 2))
        end_month = validate_month(request.args.get('end_month'))
        history = get_month_history(current_user.id, months, end_month)
        return jsonify({'history': history, 'months': len(history)})
    except (ValueError, TypeError) as exc:
        return _json_error(str(exc))


@finance_bp.route('/savings-settings', methods=['GET', 'PUT'])
@login_required
def savings_settings():
    if request.method == 'GET':
        return jsonify(get_savings_settings(current_user.id))
    data = request.get_json(silent=True) or {}
    method = (data.get('method') or 'percentage').lower()
    if method not in {'fixed', 'percentage'}:
        return _json_error('Savings method must be fixed or percentage')
    try:
        value = round(float(data.get('value', 20)), 2)
        bonus_pct = round(float(data.get('bonus_savings_percentage', 0)), 2)
    except (TypeError, ValueError):
        return _json_error('Savings values must be numeric')
    if value < 0 or (method == 'percentage' and value > 100) or bonus_pct < 0 or bonus_pct > 100:
        return _json_error('Savings percentages must be between 0 and 100; fixed savings cannot be negative')
    enabled = 1 if data.get('enabled', True) else 0
    execute(
        """INSERT INTO savings_settings
           (user_id, savings_method, savings_value, bonus_savings_percentage, enabled)
           VALUES (%s, %s, %s, %s, %s)
           ON DUPLICATE KEY UPDATE savings_method = VALUES(savings_method),
             savings_value = VALUES(savings_value),
             bonus_savings_percentage = VALUES(bonus_savings_percentage),
             enabled = VALUES(enabled)""",
        (current_user.id, method, value, bonus_pct, enabled),
    )
    execute('DELETE FROM monthly_savings WHERE user_id = %s AND month >= %s', (current_user.id, date.today().strftime('%Y-%m')))
    return jsonify({'message': 'Savings settings updated', **get_savings_settings(current_user.id)})


@finance_bp.route('/budget-prediction', methods=['GET'])
@login_required
def budget_prediction():
    try:
        month = validate_month(request.args.get('month'))
        return jsonify(build_budget_prediction(current_user.id, month))
    except ValueError as exc:
        return _json_error(str(exc))


@finance_bp.route('/saving-tips', methods=['GET'])
@login_required
def saving_tips():
    try:
        month = validate_month(request.args.get('month'))
        return jsonify(generate_saving_tips(current_user.id, month))
    except ValueError as exc:
        return _json_error(str(exc))


@finance_bp.route('/notifications', methods=['GET'])
@login_required
def notifications():
    rows = query_all(
        """SELECT id, notification_type, title, message, is_read, created_at
           FROM user_notifications WHERE user_id = %s
           ORDER BY created_at DESC, id DESC LIMIT 30""",
        (current_user.id,),
    )
    return jsonify({'notifications': [
        {'id': r['id'], 'type': r['notification_type'], 'title': r['title'],
         'message': r['message'], 'is_read': bool(r['is_read']),
         'created_at': r['created_at'].strftime('%d %b %Y %H:%M')}
        for r in rows
    ]})


@finance_bp.route('/notifications/<int:item_id>/read', methods=['PATCH'])
@login_required
def mark_notification_read(item_id):
    execute('UPDATE user_notifications SET is_read = 1 WHERE id = %s AND user_id = %s', (item_id, current_user.id))
    return jsonify({'message': 'Notification marked as read'})


@finance_bp.route('/notifications/read-all', methods=['PATCH'])
@login_required
def mark_all_notifications_read():
    execute('UPDATE user_notifications SET is_read = 1 WHERE user_id = %s', (current_user.id,))
    return jsonify({'message': 'All notifications marked as read'})


@finance_bp.route('/notification-preferences', methods=['GET', 'PUT'])
@login_required
def notification_preferences():
    if request.method == 'GET':
        row = query_one('SELECT * FROM notification_preferences WHERE user_id = %s', (current_user.id,))
        if not row:
            execute('INSERT IGNORE INTO notification_preferences (user_id) VALUES (%s)', (current_user.id,))
            row = query_one('SELECT * FROM notification_preferences WHERE user_id = %s', (current_user.id,))
        return jsonify({
            'daily_enabled': bool(row['daily_enabled']),
            'weekly_enabled': bool(row['weekly_enabled']),
            'monthly_enabled': bool(row['monthly_enabled']),
            'browser_enabled': bool(row['browser_enabled']),
            'reminder_time': _format_time(row['reminder_time']),
        })
    data = request.get_json(silent=True) or {}
    reminder_time = data.get('reminder_time', '09:00')
    if not re.match(r'^([01]\d|2[0-3]):[0-5]\d$', str(reminder_time)):
        return _json_error('Reminder time must use HH:MM format')
    prefs = (
        1 if data.get('daily_enabled') else 0,
        1 if data.get('weekly_enabled') else 0,
        1 if data.get('monthly_enabled') else 0,
        1 if data.get('browser_enabled') else 0,
        reminder_time + ':00', current_user.id,
    )
    execute(
        """INSERT INTO notification_preferences
           (daily_enabled, weekly_enabled, monthly_enabled, browser_enabled, reminder_time, user_id)
           VALUES (%s, %s, %s, %s, %s, %s)
           ON DUPLICATE KEY UPDATE daily_enabled = VALUES(daily_enabled),
             weekly_enabled = VALUES(weekly_enabled), monthly_enabled = VALUES(monthly_enabled),
             browser_enabled = VALUES(browser_enabled), reminder_time = VALUES(reminder_time)""",
        prefs,
    )
    return jsonify({'message': 'Notification preferences saved'})
