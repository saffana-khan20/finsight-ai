from datetime import datetime, date
from flask import Response
from collections import defaultdict
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from models.expense import get_category_totals, get_monthly_totals
from models.budget import get_budgets
from ml import classifier, predictor, anomaly_detector

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/category-breakdown', methods=['GET'])
@login_required
def category_breakdown():
    # ⭐ FIX: Month parameter accept karo
    month = request.args.get('month') or datetime.now().strftime('%Y-%m')
    year, m = map(int, month.split('-'))
    
    totals = get_category_totals(current_user.id, year, m)
    grand = sum(totals.values()) or 1
    breakdown = [{'category': c, 'amount': round(a, 2), 'percentage': round(a / grand * 100, 1)} for c, a in sorted(totals.items(), key=lambda x: -x[1])]
    return jsonify({'breakdown': breakdown, 'total': round(grand, 2)})

@analytics_bp.route('/trends', methods=['GET'])
@login_required
def trends():
    months = request.args.get('months', 6, type=int)
    data = []
    now = datetime.now()
    totals = get_monthly_totals(current_user.id, months)
    for i, total in enumerate(totals):
        y = now.year
        m = now.month - (months - 1 - i)
        while m <= 0:
            m += 12
            y -= 1
        data.append({'month': f'{y}-{m:02d}', 'label': datetime(y, m, 1).strftime('%b %Y'), 'total': round(total, 2)})
    return jsonify({'trends': data})

@analytics_bp.route('/predict', methods=['GET'])
@login_required
def predict():
    try:
        months = 6
        totals = get_monthly_totals(current_user.id, months)

        if all(t == 0 for t in totals):
            now = datetime.now()
            cats = get_category_totals(current_user.id, now.year, now.month)
            current_total = sum(cats.values())
            if current_total > 0:
                totals = [0, 0, 0, 0, 0, current_total]

        total_pred = predictor.predict_next_month(totals)

        now = datetime.now()
        category_history = defaultdict(list)
        categories_list = getattr(classifier, 'CATEGORIES', ['Food', 'Travel', 'Shopping', 'Bills', 'Entertainment', 'Other'])

        for i in range(months - 1, -1, -1):
            y = now.year
            m = now.month - i
            while m <= 0:
                m += 12
                y -= 1
            cats = get_category_totals(current_user.id, y, m)
            for c in categories_list:
                category_history[c].append(cats.get(c, 0.0))

        cat_pred = predictor.predict_category_wise(dict(category_history))

        return jsonify({
            'total_prediction': total_pred,
            'category_predictions': cat_pred,
            'history': totals,
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@analytics_bp.route('/anomalies', methods=['GET'])
@login_required
def anomalies():
    from db import query_all
    rows = query_all(
        """SELECT e.*, u.name AS paid_by_name, u.avatar_initials AS paid_by_avatar
           FROM expenses e JOIN users u ON e.paid_by_id = u.id
           WHERE e.paid_by_id = %s AND e.is_anomaly = 1
           ORDER BY e.date DESC LIMIT 20""",
        (current_user.id,)
    )
    from models.expense import _hydrate
    return jsonify({'anomalies': [_hydrate(r) for r in rows]})

@analytics_bp.route('/risk', methods=['GET'])
@login_required
def risk():
    month = datetime.now().strftime('%Y-%m')
    budgets = get_budgets(current_user.id, month)
    risk_list = []
    for b in budgets:
        r = anomaly_detector.get_risk_level(b['spent'], b['limit'])
        risk_list.append({'category': b['category'], **r})
    return jsonify({'risk': risk_list})

@analytics_bp.route('/suggestions', methods=['GET'])
@login_required
def suggestions():
    month = request.args.get('month') or datetime.now().strftime('%Y-%m')
    budgets = get_budgets(current_user.id, month)
    suggestions = []
    for b in budgets:
        pct = b['percentage']
        if pct >= 100:
            suggestions.append({'type': 'danger', 'category': b['category'], 'message': f"You've exceeded your {b['category']} budget by ₹{b['spent'] - b['limit']:.0f}."})
        elif pct >= 80:
            suggestions.append({'type': 'warn', 'category': b['category'], 'message': f"Your {b['category']} budget is {pct}% used."})
    if not suggestions:
        suggestions.append({'type': 'info', 'message': 'Great job! All budgets are within healthy limits.'})
    return jsonify({'suggestions': suggestions})

def _financial_report_data(user_id, month):
    from services.finance_service import get_month_financial_summary, month_start, month_end_exclusive
    from models.budget import get_budgets, recalculate_spent
    from db import query_all

    summary = get_month_financial_summary(user_id, month)
    start, end = month_start(month), month_end_exclusive(month)
    expense_rows = query_all(
        """SELECT e.id, e.description, COALESCE(e.merchant, '') AS merchant,
                  COALESCE(e.category, 'Other') AS category, COALESCE(e.source, '') AS source,
                  e.date, es.amount AS user_amount, COALESCE(g.name, '') AS group_name
           FROM expense_splits es
           JOIN expenses e ON e.id = es.expense_id
           LEFT JOIN groups_table g ON g.id = e.group_id
           WHERE es.user_id = %s AND e.date >= %s AND e.date < %s
           ORDER BY e.date DESC, e.id DESC LIMIT 1000""",
        (user_id, start, end),
    )
    expenses = [{
        'id': r['id'], 'description': r['description'], 'merchant': r['merchant'],
        'category': r['category'], 'source': r['source'],
        'date': r['date'].strftime('%Y-%m-%d'), 'amount': round(float(r['user_amount']), 2),
        'group': r['group_name'] or 'Personal',
    } for r in expense_rows]

    contributions = query_all(
        """SELECT sc.amount, sc.note, sc.created_at, sg.goal_name
           FROM savings_contributions sc
           JOIN savings_goals sg ON sg.id = sc.goal_id
           WHERE sc.user_id = %s AND sc.created_at >= %s AND sc.created_at < %s
           ORDER BY sc.created_at DESC LIMIT 1000""",
        (user_id, start, end),
    )
    savings_contributions = [{
        'goal': r['goal_name'], 'amount': round(float(r['amount']), 2),
        'note': r['note'] or '', 'date': r['created_at'].strftime('%Y-%m-%d'),
    } for r in contributions]

    budgets = get_budgets(user_id, month)
    for b in budgets:
        recalculate_spent(user_id, b['category'], month)
    budgets = get_budgets(user_id, month)
    budget_rows = [{
        'category': b['category'], 'budget': round(float(b['limit']), 2),
        'spent': round(float(b['spent']), 2),
        'remaining': round(max(float(b['limit']) - float(b['spent']), 0), 2),
        'variance': round(float(b['spent']) - float(b['limit']), 2),
    } for b in budgets]

    return {
        'month': month,
        'summary': summary,
        'income': [
            {'type': 'Salary', 'description': 'Regular monthly salary', 'date': month + '-01', 'amount': summary['salary_income']},
            *[{'type': item['income_type'].title(), 'description': item['description'],
               'date': item['transaction_date'], 'amount': item['amount']}
              for item in summary['income_transactions']],
        ],
        'expenses': expenses,
        'savings_contributions': savings_contributions,
        'budgets': budget_rows,
        'category_expenses': summary['category_expenses'],
        'totals': {
            'salary': summary['salary_income'], 'additional_income': summary['additional_income'],
            'income': summary['total_income'], 'expenses': summary['total_expenses'],
            'automatic_savings_reserved': summary['automatic_savings'],
            'goal_contributions': round(sum(item['amount'] for item in savings_contributions), 2),
            'spendable_budget': summary['spendable_budget'],
            'unallocated_after_expenses': summary['unallocated_after_expenses'],
        }
    }


@analytics_bp.route('/report', methods=['GET'])
@login_required
def financial_report():
    from services.finance_service import validate_month
    try:
        month = validate_month(request.args.get('month'))
        return jsonify({'report': _financial_report_data(current_user.id, month)})
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400


@analytics_bp.route('/report.pdf', methods=['GET'])
@login_required
def financial_report_pdf():
    from services.finance_service import validate_month
    from io import BytesIO
    try:
        month = validate_month(request.args.get('month'))
        report = _financial_report_data(current_user.id, month)
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT, TA_RIGHT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=16*mm, leftMargin=16*mm,
                                topMargin=15*mm, bottomMargin=15*mm, title=f'FinSight AI Financial Report {month}')
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='FinTitle', parent=styles['Title'], fontSize=20, leading=24, textColor=colors.HexColor('#39327f'), alignment=TA_LEFT, spaceAfter=4))
        styles.add(ParagraphStyle(name='FinMuted', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#687080')))
        styles.add(ParagraphStyle(name='FinSection', parent=styles['Heading2'], fontSize=12, leading=15, textColor=colors.HexColor('#28264b'), spaceBefore=10, spaceAfter=6))
        styles.add(ParagraphStyle(name='FinSmall', parent=styles['Normal'], fontSize=7.5, leading=9))
        story = [Paragraph('FinSight AI', styles['FinTitle']),
                 Paragraph(f'Monthly Financial Report · {month}', styles['Heading2']),
                 Paragraph('Amounts shown in INR. Expenses reflect this user’s allocated share of personal and group transactions.', styles['FinMuted']), Spacer(1, 8)]
        totals = report['totals']
        summary_data = [
            ['Regular salary', f"INR {totals['salary']:,.2f}", 'Additional income', f"INR {totals['additional_income']:,.2f}"],
            ['Total income', f"INR {totals['income']:,.2f}", 'Total expenses', f"INR {totals['expenses']:,.2f}"],
            ['Automatic savings reserved', f"INR {totals['automatic_savings_reserved']:,.2f}", 'Spendable budget', f"INR {totals['spendable_budget']:,.2f}"],
            ['Savings goal contributions', f"INR {totals['goal_contributions']:,.2f}", 'Unallocated after expenses', f"INR {totals['unallocated_after_expenses']:,.2f}"],
        ]
        table = Table(summary_data, colWidths=[43*mm, 43*mm, 43*mm, 43*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#f4f5fb')),
            ('TEXTCOLOR',(0,0),(-1,-1),colors.HexColor('#22283a')),
            ('FONTNAME',(0,0),(-1,-1),'Helvetica'), ('FONTSIZE',(0,0),(-1,-1),8),
            ('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#e2e4ed')),
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('LEFTPADDING',(0,0),(-1,-1),7),
            ('TOPPADDING',(0,0),(-1,-1),7), ('BOTTOMPADDING',(0,0),(-1,-1),7),
        ]))
        story += [table, Paragraph('Income transactions', styles['FinSection'])]
        income_data = [['Date', 'Type', 'Description', 'Amount (INR)']]
        for item in report['income']:
            income_data.append([item['date'], item['type'], Paragraph(xml_escape(str(item['description'])[:120]), styles['FinSmall']), f"{item['amount']:,.2f}"])
        if len(income_data) == 1: income_data.append(['—', '—', 'No income records', '0.00'])
        it = Table(income_data, colWidths=[25*mm, 27*mm, 92*mm, 28*mm], repeatRows=1)
        it.setStyle(_pdf_table_style(colors))
        story.append(it)

        story.append(Paragraph('Expenses and transactions', styles['FinSection']))
        expense_data = [['Date', 'Category', 'Description / Merchant', 'Payment', 'Your share (INR)']]
        for item in report['expenses']:
            descr = item['description'] + (f" / {item['merchant']}" if item['merchant'] else '')
            expense_data.append([item['date'], item['category'], Paragraph(xml_escape(str(descr)[:130]), styles['FinSmall']), item['source'] or '—', f"{item['amount']:,.2f}"])
        if len(expense_data) == 1: expense_data.append(['—', '—', 'No expense transactions', '—', '0.00'])
        et = Table(expense_data, colWidths=[20*mm, 25*mm, 70*mm, 22*mm, 30*mm], repeatRows=1)
        et.setStyle(_pdf_table_style(colors))
        story.append(et)

        story.append(Paragraph('Category budget vs actual', styles['FinSection']))
        budget_data = [['Category', 'Planned (INR)', 'Actual (INR)', 'Remaining (INR)', 'Variance (INR)']]
        for item in report['budgets']:
            budget_data.append([item['category'], f"{item['budget']:,.2f}", f"{item['spent']:,.2f}", f"{item['remaining']:,.2f}", f"{item['variance']:,.2f}"])
        if len(budget_data) == 1: budget_data.append(['No budgets saved', '0.00', '0.00', '0.00', '0.00'])
        bt = Table(budget_data, colWidths=[38*mm, 34*mm, 34*mm, 34*mm, 34*mm], repeatRows=1)
        bt.setStyle(_pdf_table_style(colors))
        story.append(bt)

        story.append(Paragraph('Savings goal contributions', styles['FinSection']))
        savings_data = [['Date', 'Goal', 'Note', 'Contribution (INR)']]
        for item in report['savings_contributions']:
            savings_data.append([item['date'], item['goal'], Paragraph(xml_escape(str(item['note'])[:100]), styles['FinSmall']), f"{item['amount']:,.2f}"])
        if len(savings_data) == 1: savings_data.append(['—', 'No contributions', 'Automatic savings reserve is reported above', '0.00'])
        st = Table(savings_data, colWidths=[22*mm, 40*mm, 75*mm, 30*mm], repeatRows=1)
        st.setStyle(_pdf_table_style(colors))
        story += [st, Spacer(1, 10), Paragraph('Generated by FinSight AI. This report is for personal tracking and is not financial or tax advice.', styles['FinMuted'])]
        doc.build(story)
        buffer.seek(0)
        return Response(buffer.getvalue(), mimetype='application/pdf', headers={
            'Content-Disposition': f'attachment; filename="FinSightAI_Report_{month}.pdf"'
        })
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400


def _pdf_table_style(colors):
    from reportlab.platypus import TableStyle
    return TableStyle([
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#635bff')),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'), ('FONTNAME',(0,1),(-1,-1),'Helvetica'),
        ('FONTSIZE',(0,0),(-1,-1),7), ('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#e1e3ea')),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, colors.HexColor('#f7f8fb')]),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('LEFTPADDING',(0,0),(-1,-1),5),
        ('TOPPADDING',(0,0),(-1,-1),5), ('BOTTOMPADDING',(0,0),(-1,-1),5),
    ])


@analytics_bp.route('/expense-insights', methods=['GET'])
@login_required
def expense_insights():
    """Explain unusual transactions using the preceding three months as a baseline."""
    from services.finance_service import validate_month, shift_month, month_start, month_end_exclusive
    from db import query_all
    try:
        month = validate_month(request.args.get('month'))
        previous = [shift_month(month, offset) for offset in (-3, -2, -1)]
        start, end = month_start(month), month_end_exclusive(month)
        history_start = month_start(previous[0])
        history_rows = query_all(
            """SELECT COALESCE(e.category, 'Other') AS category, es.amount AS amount,
                      DATE_FORMAT(e.date, '%Y-%m') AS month
               FROM expense_splits es JOIN expenses e ON e.id = es.expense_id
               WHERE es.user_id = %s AND e.date >= %s AND e.date < %s""",
            (current_user.id, history_start, start),
        )
        current_rows = query_all(
            """SELECT e.id, e.description, COALESCE(e.merchant, '') AS merchant,
                      COALESCE(e.category, 'Other') AS category, es.amount AS amount,
                      e.date, COALESCE(e.source, '') AS source
               FROM expense_splits es JOIN expenses e ON e.id = es.expense_id
               WHERE es.user_id = %s AND e.date >= %s AND e.date < %s
               ORDER BY e.date DESC, e.id DESC LIMIT 500""",
            (current_user.id, start, end),
        )
        from collections import defaultdict
        history_by_cat = defaultdict(lambda: defaultdict(float))
        history_txns = defaultdict(list)
        for row in history_rows:
            category = row['category'] or 'Other'
            amount = float(row['amount'] or 0)
            history_by_cat[category][row['month']] += amount
            history_txns[category].append(amount)
        current_by_cat = defaultdict(float)
        for row in current_rows:
            current_by_cat[row['category'] or 'Other'] += float(row['amount'] or 0)

        insights = []
        for category, current_total in current_by_cat.items():
            monthly_values = [history_by_cat[category].get(m, 0.0) for m in previous]
            avg_monthly = sum(monthly_values) / 3.0
            if avg_monthly >= 500 and current_total > avg_monthly * 1.35:
                insights.append({
                    'kind': 'category_spike', 'severity': 'high' if current_total > avg_monthly * 1.75 else 'medium',
                    'category': category, 'current_spending': round(current_total, 2),
                    'historical_monthly_average': round(avg_monthly, 2),
                    'message': f'{category} spending is {round((current_total / avg_monthly - 1) * 100)}% above the previous three-month monthly average.',
                    'recommendation': f'Review recent {category.lower()} purchases and consider setting a tighter category limit.'
                })

        for row in current_rows:
            category = row['category'] or 'Other'
            historical = history_txns.get(category, [])
            amount = float(row['amount'] or 0)
            if len(historical) < 3 or amount < 1000:
                continue
            avg_txn = sum(historical) / len(historical)
            avg_month = sum(history_by_cat[category].get(m, 0.0) for m in previous) / 3.0
            threshold = max(avg_txn * 2.5, avg_month * 0.75, 1000.0)
            from ml import anomaly_detector
            zscore_flag = anomaly_detector.detect(amount, historical)
            if zscore_flag or amount >= threshold:
                insights.append({
                    'kind': 'unusual_transaction', 'severity': 'high' if amount >= threshold * 1.5 else 'medium',
                    'transaction_id': row['id'], 'category': category,
                    'description': row['description'], 'merchant': row['merchant'],
                    'date': row['date'].strftime('%Y-%m-%d'), 'amount': round(amount, 2),
                    'historical_transaction_average': round(avg_txn, 2),
                    'detected_by': 'Z-score anomaly detector' if zscore_flag else 'three-month category baseline',
                    'message': f'Your {category.lower()} expense of INR {amount:,.2f} is significantly higher than your previous spending pattern.',
                    'recommendation': 'Review this transaction to confirm it is expected and correctly categorized.'
                })

        insights.sort(key=lambda item: (item['severity'] == 'high', item.get('amount', item.get('current_spending', 0))), reverse=True)
        return jsonify({'month': month, 'baseline_months': previous, 'insights': insights,
                        'count': len(insights), 'message': 'Insights compare transactions and category totals with the preceding three months. They are review flags, not fraud determinations.'})
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
