from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from models.budget import upsert_budget, get_budgets, delete_budget, recalculate_spent
from db import query_one, execute

budgets_bp = Blueprint('budgets', __name__)

@budgets_bp.route('/', methods=['GET'])
@login_required
def list_budgets():
    month = request.args.get('month') or datetime.now().strftime('%Y-%m')
    _maybe_rollover(current_user.id, month)
    budgets = get_budgets(current_user.id, month)
    for b in budgets:
        recalculate_spent(current_user.id, b['category'], month)
    budgets = get_budgets(current_user.id, month)
    return jsonify({'budgets': budgets, 'month': month})

def _maybe_rollover(user_id, month):
    existing = query_one("SELECT COUNT(*) AS c FROM budgets WHERE user_id = %s AND month = %s", (user_id, month))
    if existing and existing['c'] > 0:
        return
    y, m = map(int, month.split('-'))
    prev_m = m - 1 if m > 1 else 12
    prev_y = y if m > 1 else y - 1
    prev_month = f"{prev_y}-{prev_m:02d}"
    from db import query_all
    prev_budgets = query_all("SELECT category, limit_amount FROM budgets WHERE user_id = %s AND month = %s", (user_id, prev_month))
    for pb in prev_budgets:
        try:
            execute("INSERT IGNORE INTO budgets (user_id, category, limit_amount, month, spent_amount) VALUES (%s, %s, %s, %s, 0)", (user_id, pb['category'], pb['limit_amount'], month))
        except Exception:
            pass

@budgets_bp.route('/', methods=['POST'])
@login_required
def create():
    data = request.get_json() or {}
    month = data.get('month') or datetime.now().strftime('%Y-%m')
    category = (data.get('category') or '').strip()[:50]
    limit = float(data.get('limit') or 0)
    if not category or limit <= 0:
        return jsonify({'error': 'Category and positive limit required'}), 400
    bid = upsert_budget(user_id=current_user.id, category=category, limit_amount=limit, month=month, alert_threshold=float(data.get('alert_threshold', 0.80)))
    recalculate_spent(current_user.id, category, month)
    return jsonify({'id': bid, 'message': 'Saved'}), 201

@budgets_bp.route('/<int:bid>', methods=['DELETE'])
@login_required
def remove(bid):
    if not delete_budget(bid, current_user.id):
        return jsonify({'error': 'Not found'}), 404
    return jsonify({'message': 'Deleted'})

@budgets_bp.route('/ai-plan', methods=['POST'])
@login_required
def generate_ai_plan():
    """Generate a review-only category budget plan; this endpoint does not save budgets."""
    data = request.get_json(silent=True) or {}
    try:
        from services.finance_service import validate_month
        from ai.budget_optimizer import generate_three_month_budget_plan
        month = validate_month(data.get('month'))
        plan = generate_three_month_budget_plan(current_user.id, month)
        return jsonify({'plan': plan, 'saved': False})
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400


@budgets_bp.route('/ai-plan/apply', methods=['POST'])
@login_required
def apply_ai_plan():
    """Persist only the reviewed allocations submitted by the user."""
    from decimal import Decimal, InvalidOperation
    from db import transaction
    from services.finance_service import validate_month, get_month_financial_summary

    data = request.get_json(silent=True) or {}
    try:
        month = validate_month(data.get('month'))
        allocations = data.get('allocations')
        if not isinstance(allocations, list) or not allocations or len(allocations) > 30:
            raise ValueError('A non-empty budget plan is required')
        cleaned = []
        seen = set()
        total = Decimal('0.00')
        for item in allocations:
            category = str(item.get('category') or '').strip()[:50]
            amount = Decimal(str(item.get('amount', 0)))
            if not category or category in seen:
                raise ValueError('Each budget category must be unique')
            if not amount.is_finite() or amount <= 0:
                raise ValueError('Budget amounts must be positive numbers')
            seen.add(category)
            amount = amount.quantize(Decimal('0.01'))
            total += amount
            cleaned.append((category, amount))
        summary = get_month_financial_summary(current_user.id, month)
        if total > Decimal(str(summary['spendable_budget'])):
            raise ValueError('The plan exceeds your spendable budget after savings')

        with transaction() as (conn, cursor):
            for category, amount in cleaned:
                cursor.execute(
                    """INSERT INTO budgets (user_id, category, limit_amount, month, spent_amount, alert_threshold)
                       VALUES (%s, %s, %s, %s, 0, 0.80)
                       ON DUPLICATE KEY UPDATE limit_amount = VALUES(limit_amount)""",
                    (current_user.id, category, float(amount), month),
                )
        return jsonify({'message': 'Budget plan applied successfully', 'month': month,
                        'total': float(total), 'categories_saved': len(cleaned)})
    except (ValueError, InvalidOperation, TypeError) as exc:
        return jsonify({'error': str(exc)}), 400


@budgets_bp.route('/optimizer', methods=['GET'])
@login_required
def budget_optimizer_preview():
    from services.finance_service import validate_month
    from ai.budget_optimizer import build_budget_optimizer
    try:
        month = validate_month(request.args.get('month'))
        return jsonify(build_budget_optimizer(current_user.id, month))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400


@budgets_bp.route('/optimizer/apply', methods=['POST'])
@login_required
def apply_budget_optimizer():
    """Accept suggested budget transfers. Rejected suggestions are never persisted."""
    from decimal import Decimal, InvalidOperation
    from db import transaction
    from services.finance_service import validate_month
    from models.budget import get_budgets, recalculate_spent

    data = request.get_json(silent=True) or {}
    try:
        month = validate_month(data.get('month'))
        transfers = data.get('transfers')
        if not isinstance(transfers, list) or not transfers or len(transfers) > 30:
            raise ValueError('Select at least one recommendation to apply')
        # Refresh spend totals before validating available source budget.
        current = get_budgets(current_user.id, month)
        for item in current:
            recalculate_spent(current_user.id, item['category'], month)

        source_totals = {}
        target_totals = {}
        for item in transfers:
            source = str(item.get('from_category') or '').strip()[:50]
            target = str(item.get('to_category') or '').strip()[:50]
            amount = Decimal(str(item.get('amount', 0))).quantize(Decimal('0.01'))
            if not source or not target or source == target:
                raise ValueError('Each transfer must have different source and target categories')
            if not amount.is_finite() or amount <= 0:
                raise ValueError('Transfer amounts must be positive')
            source_totals[source] = source_totals.get(source, Decimal('0.00')) + amount
            target_totals[target] = target_totals.get(target, Decimal('0.00')) + amount

        with transaction() as (conn, cursor):
            rows = {}
            for category in set(source_totals) | set(target_totals):
                cursor.execute(
                    "SELECT id, category, limit_amount, spent_amount FROM budgets WHERE user_id = %s AND month = %s AND category = %s FOR UPDATE",
                    (current_user.id, month, category),
                )
                row = cursor.fetchone()
                if not row:
                    raise ValueError(f'Budget for {category} no longer exists; refresh recommendations')
                rows[category] = row
            for source, amount in source_totals.items():
                available = Decimal(str(rows[source]['limit_amount'])) - Decimal(str(rows[source]['spent_amount']))
                if amount > available:
                    raise ValueError(f'{source} no longer has enough unspent budget; refresh recommendations')
            for source, amount in source_totals.items():
                cursor.execute('UPDATE budgets SET limit_amount = limit_amount - %s WHERE id = %s AND user_id = %s',
                               (float(amount), rows[source]['id'], current_user.id))
            for target, amount in target_totals.items():
                cursor.execute('UPDATE budgets SET limit_amount = limit_amount + %s WHERE id = %s AND user_id = %s',
                               (float(amount), rows[target]['id'], current_user.id))
        return jsonify({'message': 'Budget adjustments accepted and saved', 'month': month,
                        'transfers_applied': len(transfers)})
    except (ValueError, InvalidOperation, TypeError) as exc:
        return jsonify({'error': str(exc)}), 400
